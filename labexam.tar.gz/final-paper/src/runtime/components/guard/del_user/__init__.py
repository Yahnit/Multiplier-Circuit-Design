
print "runtime.components.guard.del_user package"
